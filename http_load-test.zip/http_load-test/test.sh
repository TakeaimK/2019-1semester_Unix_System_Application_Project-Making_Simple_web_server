echo TEST static htmls
./http_load -rate 100 -seconds 10 urls 

